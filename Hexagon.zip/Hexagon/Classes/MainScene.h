//
//  MainScene.h
//  Hexagon
//

#ifndef MainScene_h
#define MainScene_h

#include "cocos2d.h"
#include <vector>
USING_NS_CC;
using namespace std;

typedef enum
{
    TAG_LAYER,
}TAG;

typedef enum
{
    DIRECTION_LEFT,
    DIRECTION_LEFT_UP,
    DIRECTION_LEFT_DOWN,
    DIRECTION_RIGHT,
    DIRECTION_RIGHT_UP,
    DIRECTION_RIGHT_DOWN,
}Direction;

struct MapPosition
{
    int v1, v2, v3;
    int value;
    CCPoint point;
};

class MainScene : public CCLayer
{
public:
    static CCScene * scene();
    CREATE_FUNC(MainScene);
    
    MainScene();
    virtual ~MainScene();
    
    virtual bool init();
    
    void initMapPosition();
    void startGame();
    
    void moveNumber(Direction direction);
    void displayNumber();
    void createRandomNumber();
    
    void registerWithTouchDispatcher();
    bool ccTouchBegan(CCTouch * touch, CCEvent * event);
    void ccTouchMoved(CCTouch * touch, CCEvent * event);
    void ccTouchEnded(CCTouch * touch, CCEvent * event);
    
private:
    vector<MapPosition*> * vecMapPosition;
    
    vector<vector<MapPosition*> *> * vecMapPosU;
    vector<vector<MapPosition*> *> * vecMapPosC;
    vector<vector<MapPosition*> *> * vecMapPosD;
    
    vector<MapPosition*> * vecMapPosU0;
    vector<MapPosition*> * vecMapPosU1;
    vector<MapPosition*> * vecMapPosU2;
    vector<MapPosition*> * vecMapPosU3;
    vector<MapPosition*> * vecMapPosU4;
    
    vector<MapPosition*> * vecMapPosC0;
    vector<MapPosition*> * vecMapPosC1;
    vector<MapPosition*> * vecMapPosC2;
    vector<MapPosition*> * vecMapPosC3;
    vector<MapPosition*> * vecMapPosC4;
    
    vector<MapPosition*> * vecMapPosD0;
    vector<MapPosition*> * vecMapPosD1;
    vector<MapPosition*> * vecMapPosD2;
    vector<MapPosition*> * vecMapPosD3;
    vector<MapPosition*> * vecMapPosD4;
};

#endif /* MainScene_h */
