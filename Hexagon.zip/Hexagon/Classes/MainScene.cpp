//
//  MainScene.cpp
//  Hexagon
//

#include "MainScene.h"
#include <cmath>

#define DISTANCE 120.0f
#define SQUARE3 1.7320508f
#define SQUARE3_HALF_DISTANCE 0.5f * SQUARE3 * DISTANCE
#define NEAR_ZERO 1e-4f
#define PI 3.1415926f

CCScene * MainScene::scene()
{
    CCScene * scene = CCScene::create();
    MainScene * layer = MainScene::create();
    scene->addChild(layer);
    return scene;
}

MainScene::MainScene()
{
    vecMapPosition = new vector<MapPosition*>;
    
    vecMapPosU0 = new vector<MapPosition*>;
    vecMapPosU1 = new vector<MapPosition*>;
    vecMapPosU2 = new vector<MapPosition*>;
    vecMapPosU3 = new vector<MapPosition*>;
    vecMapPosU4 = new vector<MapPosition*>;
    
    vecMapPosC0 = new vector<MapPosition*>;
    vecMapPosC1 = new vector<MapPosition*>;
    vecMapPosC2 = new vector<MapPosition*>;
    vecMapPosC3 = new vector<MapPosition*>;
    vecMapPosC4 = new vector<MapPosition*>;
    
    vecMapPosD0 = new vector<MapPosition*>;
    vecMapPosD1 = new vector<MapPosition*>;
    vecMapPosD2 = new vector<MapPosition*>;
    vecMapPosD3 = new vector<MapPosition*>;
    vecMapPosD4 = new vector<MapPosition*>;
    
    vecMapPosU = new vector<vector<MapPosition*> *>;
    vecMapPosU->clear();
    vecMapPosU->push_back(vecMapPosU0);
    vecMapPosU->push_back(vecMapPosU1);
    vecMapPosU->push_back(vecMapPosU2);
    vecMapPosU->push_back(vecMapPosU3);
    vecMapPosU->push_back(vecMapPosU4);
    
    vecMapPosC = new vector<vector<MapPosition*> *>;
    vecMapPosC->clear();
    vecMapPosC->push_back(vecMapPosC0);
    vecMapPosC->push_back(vecMapPosC1);
    vecMapPosC->push_back(vecMapPosC2);
    vecMapPosC->push_back(vecMapPosC3);
    vecMapPosC->push_back(vecMapPosC4);
    
    vecMapPosD = new vector<vector<MapPosition*> *>;
    vecMapPosD->clear();
    vecMapPosD->push_back(vecMapPosD0);
    vecMapPosD->push_back(vecMapPosD1);
    vecMapPosD->push_back(vecMapPosD2);
    vecMapPosD->push_back(vecMapPosD3);
    vecMapPosD->push_back(vecMapPosD4);
}

MainScene::~MainScene()
{
    for(int i = 0; i < vecMapPosition->size(); ++i)
    {
        CC_SAFE_DELETE(vecMapPosition->at(i));
    }
    CC_SAFE_DELETE(vecMapPosition);
    
    
    for(int i = 0; i < vecMapPosU->size(); ++i)
    {
        CC_SAFE_DELETE(vecMapPosU->at(i));
    }
    CC_SAFE_DELETE(vecMapPosU);
    
    for(int i = 0; i < vecMapPosC->size(); ++i)
    {
        CC_SAFE_DELETE(vecMapPosC->at(i));
    }
    CC_SAFE_DELETE(vecMapPosC);
    
    for(int i = 0; i < vecMapPosD->size(); ++i)
    {
        CC_SAFE_DELETE(vecMapPosD->at(i));
    }
    CC_SAFE_DELETE(vecMapPosD);
}

bool MainScene::init()
{
    if(!CCLayer::init())
        return false;
    
    setTouchEnabled(true);
    
    CCSize winSize = CCDirector::sharedDirector()->getWinSize();
    CCLayerColor * layer = CCLayerColor::create(ccc4(200, 190, 180, 250), winSize.width, winSize.height);
    this->addChild(layer,0,TAG_LAYER);
    
    initMapPosition();
    
    startGame();
    
    return true;
}

void MainScene::initMapPosition()
{
    CCSize winSize = CCDirector::sharedDirector()->getWinSize();
    CCPoint center = CCPoint(winSize.width * 0.5, winSize.height * 0.5);
    double xCenter = center.x;
    double yCenter = center.y;
    
    //--- (002)(101)(200)
    for(int i = 0; i < 3; ++i)
    {
        MapPosition * mapPosition = new MapPosition();
        mapPosition->v1 = i;
        mapPosition->v2 = 0;
        mapPosition->v3 = 2 - i;
        mapPosition->value = 0;
        mapPosition->point = CCPoint(xCenter + (1 - i) * DISTANCE, yCenter + SQUARE3_HALF_DISTANCE * 2);
        vecMapPosition->push_back(mapPosition);
        vecMapPosU->at(mapPosition->v1)->push_back(mapPosition);
        vecMapPosC->at(mapPosition->v2)->push_back(mapPosition);
        vecMapPosD->at(mapPosition->v3)->push_back(mapPosition);
    }
    
    //--- (013)(112)(211)(310)
    for(int i = 0; i < 4; ++i)
    {
        MapPosition * mapPosition = new MapPosition();
        mapPosition->v1 = i;
        mapPosition->v2 = 1;
        mapPosition->v3 = 3 - i;
        mapPosition->value = 0;
        mapPosition->point = CCPoint(xCenter + (1.5 - i) * DISTANCE, yCenter + SQUARE3_HALF_DISTANCE);
        vecMapPosition->push_back(mapPosition);
        vecMapPosU->at(mapPosition->v1)->push_back(mapPosition);
        vecMapPosC->at(mapPosition->v2)->push_back(mapPosition);
        vecMapPosD->at(mapPosition->v3)->push_back(mapPosition);
    }
    
    //--- (024)(123)(222)(321)(420)
    for(int i = 0; i < 5; ++i)
    {
        MapPosition * mapPosition = new MapPosition();
        mapPosition->v1 = i;
        mapPosition->v2 = 2;
        mapPosition->v3 = 4 - i;
        mapPosition->value = 0;
        mapPosition->point = CCPoint(xCenter + (2 - i) * DISTANCE, yCenter);
        vecMapPosition->push_back(mapPosition);
        vecMapPosU->at(mapPosition->v1)->push_back(mapPosition);
        vecMapPosC->at(mapPosition->v2)->push_back(mapPosition);
        vecMapPosD->at(mapPosition->v3)->push_back(mapPosition);
    }
    
    //--- (134)(233)(332)(431)
    for(int i = 1; i < 5; ++i)
    {
        MapPosition * mapPosition = new MapPosition();
        mapPosition->v1 = i;
        mapPosition->v2 = 3;
        mapPosition->v3 = 5 - i;
        mapPosition->value = 0;
        mapPosition->point = CCPoint(xCenter + (2.5 - i) * DISTANCE, yCenter - SQUARE3_HALF_DISTANCE);
        vecMapPosition->push_back(mapPosition);
        vecMapPosU->at(mapPosition->v1)->push_back(mapPosition);
        vecMapPosC->at(mapPosition->v2)->push_back(mapPosition);
        vecMapPosD->at(mapPosition->v3)->push_back(mapPosition);
    }
    
    //--- (244)(343)(442)
    for(int i = 2; i < 5; ++i)
    {
        MapPosition * mapPosition = new MapPosition();
        mapPosition->v1 = i;
        mapPosition->v2 = 4;
        mapPosition->v3 = 6 - i;
        mapPosition->value = 0;
        mapPosition->point = CCPoint(xCenter + (3 - i) * DISTANCE, yCenter - SQUARE3_HALF_DISTANCE * 2);
        vecMapPosition->push_back(mapPosition);
        vecMapPosU->at(mapPosition->v1)->push_back(mapPosition);
        vecMapPosC->at(mapPosition->v2)->push_back(mapPosition);
        vecMapPosD->at(mapPosition->v3)->push_back(mapPosition);
    }
}

void MainScene::startGame()
{
    createRandomNumber();
    createRandomNumber();
    displayNumber();
}

void MainScene::moveNumber(Direction direction)
{
    if(direction == DIRECTION_LEFT_UP)
    {
        for(int i = 0; i < vecMapPosU->size(); ++i)
        {
            vector<MapPosition*> * vecMapPosUU = vecMapPosU->at(i);
            for(int j = 0; j < vecMapPosUU->size(); ++j)
            {
                for(int k = j + 1; k < vecMapPosUU->size(); ++k)
                {
                    if(vecMapPosUU->at(k)->value > 0)
                    {
                        if(vecMapPosUU->at(j)->value <= 0)
                        {
                            vecMapPosUU->at(j)->value = vecMapPosUU->at(k)->value;
                            vecMapPosUU->at(k)->value = 0;
                            --j;
                        }
                        else if(vecMapPosUU->at(j)->value == vecMapPosUU->at(k)->value)
                        {
                            vecMapPosUU->at(j)->value *= 2;
                            vecMapPosUU->at(k)->value = 0;
                        }
                        break;
                    }
                }
            }
        }
    }

    if(direction == DIRECTION_RIGHT_DOWN)
    {
        for(int i = 0; i < vecMapPosU->size(); ++i)
        {
            vector<MapPosition*> * vecMapPosUU = vecMapPosU->at(i);
            for(int j = (int)vecMapPosUU->size() - 1; j >= 0; --j)
            {
                for(int k = j - 1; k >= 0; --k)
                {
                    if(vecMapPosUU->at(k)->value > 0)
                    {
                        if(vecMapPosUU->at(j)->value <= 0)
                        {
                            vecMapPosUU->at(j)->value = vecMapPosUU->at(k)->value;
                            vecMapPosUU->at(k)->value = 0;
                            ++j;
                        }
                        else if(vecMapPosUU->at(j)->value == vecMapPosUU->at(k)->value)
                        {
                            vecMapPosUU->at(j)->value *= 2;
                            vecMapPosUU->at(k)->value = 0;
                        }
                        break;
                    }
                }
            }
        }
    }

    if(direction == DIRECTION_RIGHT)
    {
        for(int i = 0; i < vecMapPosC->size(); ++i)
        {
            vector<MapPosition*> * vecMapPosCC = vecMapPosC->at(i);
            for(int j = 0; j < vecMapPosCC->size(); ++j)
            {
                for(int k = j + 1; k < vecMapPosCC->size(); ++k)
                {
                    if(vecMapPosCC->at(k)->value > 0)
                    {
                        if(vecMapPosCC->at(j)->value <= 0)
                        {
                            vecMapPosCC->at(j)->value = vecMapPosCC->at(k)->value;
                            vecMapPosCC->at(k)->value = 0;
                            --j;
                        }
                        else if(vecMapPosCC->at(j)->value == vecMapPosCC->at(k)->value)
                        {
                            vecMapPosCC->at(j)->value *= 2;
                            vecMapPosCC->at(k)->value = 0;
                        }
                        break;
                    }
                }
            }
        }
    }

    if(direction == DIRECTION_LEFT)
    {
        for(int i = 0; i < vecMapPosC->size(); ++i)
        {
            vector<MapPosition*> * vecMapPosCC = vecMapPosC->at(i);
            for(int j = (int)vecMapPosCC->size() - 1; j >= 0; --j)
            {
                for(int k = j - 1; k >= 0; --k)
                {
                    if(vecMapPosCC->at(k)->value > 0)
                    {
                        if(vecMapPosCC->at(j)->value <= 0)
                        {
                            vecMapPosCC->at(j)->value = vecMapPosCC->at(k)->value;
                            vecMapPosCC->at(k)->value = 0;
                            ++j;
                        }
                        else if(vecMapPosCC->at(j)->value == vecMapPosCC->at(k)->value)
                        {
                            vecMapPosCC->at(j)->value *= 2;
                            vecMapPosCC->at(k)->value = 0;
                        }
                        break;
                    }
                }
            }
        }
    }
    
    if(direction == DIRECTION_RIGHT_UP)
    {
        for(int i = 0; i < vecMapPosD->size(); ++i)
        {
            vector<MapPosition*> * vecMapPosDD = vecMapPosD->at(i);
            for(int j = 0; j < vecMapPosDD->size(); ++j)
            {
                for(int k = j + 1; k < vecMapPosDD->size(); ++k)
                {
                    if(vecMapPosDD->at(k)->value > 0)
                    {
                        if(vecMapPosDD->at(j)->value <= 0)
                        {
                            vecMapPosDD->at(j)->value = vecMapPosDD->at(k)->value;
                            vecMapPosDD->at(k)->value = 0;
                            --j;
                        }
                        else if(vecMapPosDD->at(j)->value == vecMapPosDD->at(k)->value)
                        {
                            vecMapPosDD->at(j)->value *= 2;
                            vecMapPosDD->at(k)->value = 0;
                        }
                        break;
                    }
                }
            }
        }
    }
    
    if(direction == DIRECTION_LEFT_DOWN)
    {
        for(int i = 0; i < vecMapPosD->size(); ++i)
        {
            vector<MapPosition*> * vecMapPosDD = vecMapPosD->at(i);
            for(int j = (int)vecMapPosDD->size() - 1; j >= 0; --j)
            {
                for(int k = j - 1; k >= 0; --k)
                {
                    if(vecMapPosDD->at(k)->value > 0)
                    {
                        if(vecMapPosDD->at(j)->value <= 0)
                        {
                            vecMapPosDD->at(j)->value = vecMapPosDD->at(k)->value;
                            vecMapPosDD->at(k)->value = 0;
                            ++j;
                        }
                        else if(vecMapPosDD->at(j)->value == vecMapPosDD->at(k)->value)
                        {
                            vecMapPosDD->at(j)->value *= 2;
                            vecMapPosDD->at(k)->value = 0;
                        }
                        break;
                    }
                }
            }
        }
    }
    
    createRandomNumber();
    displayNumber();
}

void MainScene::displayNumber()
{
    CCLayer * layer = (CCLayer *)getChildByTag(TAG_LAYER);
    layer->removeAllChildren();
    //setColor();
    
    for(int i = 0; i < vecMapPosition->size(); ++i)
    {
        CCLabelTTF * label = CCLabelTTF::create(CCString::createWithFormat("%d",vecMapPosition->at(i)->value)->getCString(),"HiraKakuProN-W6",60);
        label->setAnchorPoint(ccp(0.5, 0.5));
        label->setPosition(vecMapPosition->at(i)->point);
        layer->addChild(label);
        
        if(vecMapPosition->at(i)->value == 0)
        {
            label->setColor(ccc3(200, 190, 180));
            label->setScale(1.0f);
        }
        else if(vecMapPosition->at(i)->value == 2)
        {
            label->setColor(ccc3(240, 230, 220));
            label->setScale(1.0f);
        }
        else if(vecMapPosition->at(i)->value == 4)
        {
            label->setColor(ccc3(240, 220, 200));
            label->setScale(1.0f);
        }
        else if(vecMapPosition->at(i)->value == 8)
        {
            label->setColor(ccc3(240, 180, 120));
            label->setScale(1.0f);
        }
        else if(vecMapPosition->at(i)->value == 16)
        {
            label->setColor(ccc3(240, 140, 90));
            label->setScale(0.85f);
        }
        else if(vecMapPosition->at(i)->value == 32)
        {
            label->setColor(ccc3(240, 120, 90));
            label->setScale(0.85f);
        }
        else if(vecMapPosition->at(i)->value == 64)
        {
            label->setColor(ccc3(240, 90, 60));
            label->setScale(0.85f);
        }
        else if(vecMapPosition->at(i)->value == 128)
        {
            label->setColor(ccc3(240, 90, 60));
            label->setScale(0.7f);
        }
        else if(vecMapPosition->at(i)->value == 256)
        {
            label->setColor(ccc3(240, 200, 70));
            label->setScale(0.7f);
        }
        else if(vecMapPosition->at(i)->value == 512)
        {
            label->setColor(ccc3(240, 200, 70));
            label->setScale(0.7f);
        }
        else if(vecMapPosition->at(i)->value == 1024)
        {
            label->setColor(ccc3(0, 130, 0));
            label->setScale(0.55f);
        }
    }
}

void MainScene::createRandomNumber()
{
    int index = arc4random() % 19;
    while (vecMapPosition->at(index)->value != 0)
    {
        index = arc4random() % 19;
    }
    vecMapPosition->at(index)->value = arc4random() % 5 == 0 ? 4 : 2;
}

void MainScene::registerWithTouchDispatcher()
{
    CCDirector::sharedDirector()->getTouchDispatcher()->addTargetedDelegate(this, 0, true);
}

bool MainScene::ccTouchBegan(CCTouch * touch, CCEvent * event)
{
    return true;
}

void MainScene::ccTouchMoved(CCTouch * touch, CCEvent * event)
{
    
}

void MainScene::ccTouchEnded(CCTouch * touch, CCEvent * event)
{
    CCPoint newPoint = this->convertTouchToNodeSpace(touch);
    CCPoint oldPoint = touch->getStartLocation();
    oldPoint = this->convertToNodeSpace(oldPoint);
    
    double moveX = newPoint.x - oldPoint.x;
    double moveY = newPoint.y - oldPoint.y;
    
    if(fabs(moveX) > 50 || fabs(moveY) > 50)//保证滑动距离足够大，以免误判
    {
        if(moveX >= 0)//右、右上、右下方向
        {
            if(moveY * 3.0f >= SQUARE3 * moveX)//右上
            {
                moveNumber(DIRECTION_RIGHT_UP);
            }
            else if(moveY * 3.0f <= -SQUARE3 * moveX)//右下
            {
                moveNumber(DIRECTION_RIGHT_DOWN);
            }
            else//右
            {
                moveNumber(DIRECTION_RIGHT);
            }
        }
        else//左、左上、左下
        {
            if(moveY * 3.0f <= SQUARE3 * moveX)//左下
            {
                moveNumber(DIRECTION_LEFT_DOWN);
            }
            else if(moveY * 3.0f >= -SQUARE3 * moveX)//左上
            {
                moveNumber(DIRECTION_LEFT_UP);
            }
            else//左
            {
                moveNumber(DIRECTION_LEFT);
            }
        }
    }
}

